
document.addEventListener('DOMContentLoaded', function() {

    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    const navButtons = document.querySelector('.nav-buttons');
    
    mobileMenuBtn.addEventListener('click', function() {
        navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
        navButtons.style.display = navButtons.style.display === 'flex' ? 'none' : 'flex';
    });
    
    
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            navLinks.style.display = 'flex';
            navButtons.style.display = 'flex';
        } else {
            navLinks.style.display = 'none';
            navButtons.style.display = 'none';
        }
    });
    
    
    const header = document.querySelector('header');
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
   
    const words = ["Manage", "Enable","Sell","Run"];
    let index = 0;
    const wordElement = document.getElementById("changing-word");

    function changeWord() {
      wordElement.style.animation = 'none';  
      void wordElement.offsetWidth; 
      wordElement.style.animation = 'slideOutIn 3s ease-in-out infinite';

      wordElement.textContent = words[index];
      index = (index + 1) % words.length;
    }

    changeWord(); 
    setInterval(changeWord, 3000);
    
    const tabs = document.querySelectorAll('.tab');
    const solutions = document.querySelectorAll('.solution');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            
            tabs.forEach(t => t.classList.remove('active'));
            solutions.forEach(s => s.classList.remove('active'));
            
            
            this.classList.add('active');
            
            
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
   
    

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                const headerHeight = document.querySelector('header').offsetHeight;
                const targetPosition = targetElement.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
        
                if (window.innerWidth <= 768) {
                    navLinks.style.display = 'none';
                    navButtons.style.display = 'none';
                }
            }
        });
    });
    
    
    if (solutions.length > 0) {
        solutions[0].classList.add('active');
    }
  });